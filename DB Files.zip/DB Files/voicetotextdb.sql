-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2021 at 02:35 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `voicetotextdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Emp_ID` int(11) NOT NULL,
  `UserGroup_ID` int(11) DEFAULT NULL,
  `Emp_NIC` varchar(50) NOT NULL COMMENT 'employee nic',
  `Emp_Name` varchar(50) NOT NULL COMMENT 'employee name',
  `Emp_Mobile_Num` varchar(20) NOT NULL COMMENT 'employee mobile',
  `Sent_User` varchar(50) NOT NULL COMMENT 'person who create employee',
  `UserGroup_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `Notice_ID` int(11) NOT NULL,
  `UserGroup_ID` int(11) DEFAULT NULL,
  `Notice_Priority` varchar(20) NOT NULL COMMENT 'priority-low/high',
  `Notice_Description` varchar(255) NOT NULL COMMENT 'voice notice',
  `Notice_ToWhom` varchar(50) NOT NULL COMMENT 'person who received notice',
  `Notice_From` varchar(50) NOT NULL COMMENT 'person who send notice',
  `Notice_From_U_Type` varchar(50) NOT NULL COMMENT 'group belongs person who send notice',
  `Notice_SendDate` varchar(50) NOT NULL COMMENT 'notice sent date',
  `Notice_SendTime` varchar(50) NOT NULL COMMENT 'notice sent time',
  `Lang_Type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `usergroup`
--

CREATE TABLE `usergroup` (
  `UserGroup_ID` int(11) NOT NULL,
  `UserGroup_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usergroup`
--

INSERT INTO `usergroup` (`UserGroup_ID`, `UserGroup_Name`) VALUES
(1, 'Select Group');
INSERT INTO `usergroup` (`UserGroup_ID`, `UserGroup_Name`) VALUES
(2, 'Administration');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_ID` int(11) NOT NULL,
  `UserGroup_ID` int(11) DEFAULT NULL,
  `User_NIC` varchar(50) NOT NULL COMMENT 'app user nic',
  `User_Name` varchar(50) NOT NULL COMMENT 'app user name',
  `User_MobileNo` varchar(20) NOT NULL COMMENT 'app user mobile',
  `User_Pswd` varchar(50) NOT NULL COMMENT 'app user pswd',
  `UserGroup_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Emp_ID`),
  ADD UNIQUE KEY `Emp_ID` (`Emp_ID`),
  ADD KEY `ind_ugrp_emp` (`UserGroup_ID`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`Notice_ID`),
  ADD UNIQUE KEY `Notice_ID` (`Notice_ID`),
  ADD KEY `ind_ugrp_nt` (`UserGroup_ID`);

--
-- Indexes for table `usergroup`
--
ALTER TABLE `usergroup`
  ADD PRIMARY KEY (`UserGroup_ID`),
  ADD UNIQUE KEY `UserGroup_ID` (`UserGroup_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `User_ID` (`User_ID`),
  ADD KEY `ind_ugrp_users` (`UserGroup_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `Emp_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `Notice_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usergroup`
--
ALTER TABLE `usergroup`
  MODIFY `UserGroup_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `fk_ugrp_emp` FOREIGN KEY (`UserGroup_ID`) REFERENCES `usergroup` (`UserGroup_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notice`
--
ALTER TABLE `notice`
  ADD CONSTRAINT `fk_ugrp_nt` FOREIGN KEY (`UserGroup_ID`) REFERENCES `usergroup` (`UserGroup_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_ugrp_users` FOREIGN KEY (`UserGroup_ID`) REFERENCES `usergroup` (`UserGroup_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
