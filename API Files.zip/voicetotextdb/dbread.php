<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "voicetotextdb";


$conn = mysqli_connect($servername,$username,$password,$dbname);

if (mysqli_connect_errno())
{
   echo 'Could not connect: ' . mysqli_connect_error();
   exit();
}

$sql = "SELECT * FROM notice ORDER BY Notice_ID DESC LIMIT 1"; 

//$sql = "SELECT Notice_Description FROM notice WHERE Notice_Priority = 'High' LIMIT 1"; 

//$sql = "SELECT Notice_Description FROM notice LIMIT 1"; 

$result = mysqli_query($conn,$sql);

if (!$result) {
	echo('Invalid query: ' . mysqli_error($conn));
}


while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
{
echo $row["Notice_Priority"]." - ".$row["Notice_ToWhom"]." - ".$row["Notice_Description"]." ";
}

mysqli_close($conn);

?>
