<?php
 
class DbOperation
{
    //Database connection link
    private $con;
 
    //Class constructor
    function __construct()
    {
        //Getting the DbConnect.php file
        require_once dirname(__FILE__) . '/DbConnect.php';
 
        //Creating a DbConnect object to connect to the database
        $db = new DbConnect();
 
        //Initializing our connection link of this class
        //by calling the method connect of DbConnect class
        $this->con = $db->connect();
    }
 
 //user signup
 function user_signup($User_NIC, $User_Name, $User_MobileNo, $User_Pswd, $UserGroup_Name, $UserGroup_ID){
 $stmt = $this->con->prepare("INSERT INTO users (User_NIC, User_Name, User_MobileNo, User_Pswd, UserGroup_Name, UserGroup_ID) VALUES (?, ?, ?, ?, ?, ?)");
 $stmt->bind_param("sssssi", $User_NIC, $User_Name, $User_MobileNo, $User_Pswd, $UserGroup_Name, $UserGroup_ID);
 if($stmt->execute())
 return true; 
 return false; 
 }
 
 //get all users - sign in
 function getUsers(){
 $stmt = $this->con->prepare("SELECT User_NIC, User_Name, User_Pswd, UserGroup_Name FROM users");
 $stmt->execute();
 $stmt->bind_result($User_NIC, $User_Name, $User_Pswd, $UserGroup_Name);
 
 $users = array(); 
 
 while($stmt->fetch()){
 $user  = array();
 $user['User_NIC'] = $User_NIC; 
 $user['User_Name'] = $User_Name; 
 $user['User_Pswd'] = $User_Pswd;
 $user['UserGroup_Name'] = $UserGroup_Name;
 $user['User_Pswd'] = $User_Pswd; 
 
 array_push($users, $user); 
 }
 
 return $users; 
 }


  //add new employee
 function AddNEmp($Emp_NIC, $UserGroup_ID, $Emp_Name, $Emp_Mobile_Num, $Sent_User, $UserGroup_Name){
 $stmt = $this->con->prepare("INSERT INTO employee (Emp_NIC, UserGroup_ID, Emp_Name, Emp_Mobile_Num, Sent_User, UserGroup_Name) VALUES (?, ?, ?, ?, ?,?)");
 $stmt->bind_param("sissss", $Emp_NIC, $UserGroup_ID, $Emp_Name, $Emp_Mobile_Num, $Sent_User, $UserGroup_Name);
 if($stmt->execute())
 return true; 
 return false; 
 }
 
 //get all employees
 function getEmps(){
 $stmt = $this->con->prepare("SELECT Emp_NIC, UserGroup_ID, Emp_Name, Emp_Mobile_Num, Sent_User, UserGroup_Name FROM employee");
 $stmt->execute();
 $stmt->bind_result($Emp_NIC, $UserGroup_ID, $Emp_Name, $Emp_Mobile_Num, $Sent_User, $UserGroup_Name);
 
 $emps = array(); 
 
 while($stmt->fetch()){
 $emp  = array();
 $emp['Emp_NIC'] = $Emp_NIC;
 $emp['UserGroup_ID'] = $UserGroup_ID;
 $emp['Emp_Name'] = $Emp_Name; 
 $emp['Emp_Mobile_Num'] = $Emp_Mobile_Num;
 $emp['Sent_User'] = $Sent_User;
 $emp['UserGroup_Name'] = $UserGroup_Name; 
 
 array_push($emps, $emp); 
 }
 
 return $emps; 
 }


//enter notice
 function user_enternotice($UserGroup_ID, $Notice_Priority, $Notice_Description, $Notice_ToWhom, $Notice_From, $Notice_From_U_Type, $Notice_SendDate, $Notice_SendTime, $Lang_Type){
 $stmt = $this->con->prepare("INSERT INTO notice (UserGroup_ID, Notice_Priority, Notice_Description, Notice_ToWhom, Notice_From, Notice_From_U_Type, Notice_SendDate, Notice_SendTime, Lang_Type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
 $stmt->bind_param("issssssss", $UserGroup_ID, $Notice_Priority, $Notice_Description, $Notice_ToWhom, $Notice_From, $Notice_From_U_Type, $Notice_SendDate, $Notice_SendTime, $Lang_Type);
 if($stmt->execute())
 return true; 
 return false; 
 }
 
 //get all notices
 function getNotices(){
 $stmt = $this->con->prepare("SELECT UserGroup_ID, Notice_Priority, Notice_Description, Notice_ToWhom, Notice_From, Notice_From_U_Type, Notice_SendDate, Notice_SendTime, Lang_Type FROM notice");
 $stmt->execute();
 $stmt->bind_result($UserGroup_ID, $Notice_Priority, $Notice_Description, $Notice_ToWhom, $Notice_From, $Notice_From_U_Type, $Notice_SendDate, $Notice_SendTime, $Lang_Type);
 
 $notices = array(); 
 
 while($stmt->fetch()){
 $notice  = array();
 $notice['UserGroup_ID'] = $UserGroup_ID;
 $notice['Notice_Priority'] = $Notice_Priority; 
 $notice['Notice_Description'] = $Notice_Description;
 $notice['Notice_ToWhom'] = $Notice_ToWhom;
 $notice['Notice_From'] = $Notice_From;
 $notice['Notice_From_U_Type'] = $Notice_From_U_Type; 
 $notice['Notice_SendDate'] = $Notice_SendDate; 
 $notice['Notice_SendTime'] = $Notice_SendTime; 
 $notice['Lang_Type'] = $Lang_Type; 
 array_push($notices, $notice); 
 }
 
 return $notices; 
 }
 

 //create user group
 function user_groupcreate($UserGroup_Name){
 $stmt = $this->con->prepare("INSERT INTO usergroup (UserGroup_Name) VALUES (?)");
 $stmt->bind_param("s", $UserGroup_Name);
 if($stmt->execute())
 return true; 
 return false; 
 }
 
 //get all groups
 function getGroups(){
 $stmt = $this->con->prepare("SELECT UserGroup_Name FROM usergroup");
 $stmt->execute();
 $stmt->bind_result($UserGroup_Name);
 
 $groups = array(); 
 
 while($stmt->fetch()){
 $group  = array();
 $group['UserGroup_Name'] = $UserGroup_Name; 
 array_push($groups, $group); 
 }
 
 return $groups; 
 }

  //assign employees to groups
 function emp_assign($UserGroup_ID, $UserGroup_Name, $Sent_User, $Emp_NIC){
$stmt = $this->con->prepare("UPDATE employee SET UserGroup_ID = ?, UserGroup_Name = ?, Sent_User = ? WHERE Emp_NIC = ?");
 $stmt->bind_param("isss", $UserGroup_ID, $UserGroup_Name, $Sent_User, $Emp_NIC);
 if($stmt->execute())
 return true; 
 return false; 
 }
 
 //get assign employees
 function assignEmp(){
 $stmt = $this->con->prepare("SELECT UserGroup_ID,UserGroup_Name, Sent_User, Emp_NIC FROM employee");
 $stmt->execute();
 $stmt->bind_result($UserGroup_ID, $UserGroup_Name, $Sent_User, $Emp_NIC);
 
 $emps = array(); 
 
 while($stmt->fetch()){
 $emp  = array();
 $emp['UserGroup_ID'] = $UserGroup_ID;
 $emp['UserGroup_Name'] = $UserGroup_Name;
 $emp['Sent_User'] = $Sent_User;
 $emp['Emp_NIC'] = $Emp_NIC; 
 array_push($emps, $emp); 
 }
 
 return $emps; 
 }

 //update emp mobile num
 function emp_update($Emp_Mobile_Num, $UserGroup_Name, $Emp_NIC){
 $stmt = $this->con->prepare("UPDATE employee SET Emp_Mobile_Num = ? WHERE UserGroup_Name = ? AND Emp_NIC = ?");
 $stmt->bind_param("sss", $Emp_Mobile_Num, $UserGroup_Name, $Emp_NIC);
 if($stmt->execute())
 return true; 
 return false; 
 }

 
 //The delete operation
 function deleteEmp($Emp_NIC){
 $stmt = $this->con->prepare("DELETE FROM employee WHERE Emp_NIC = ? ");
 $stmt->bind_param("s", $Emp_NIC);
 if($stmt->execute())
 return true;
 return false; 
 }
}
?>