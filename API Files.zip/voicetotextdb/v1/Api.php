<?php 
 
 //getting the dboperation class
 require_once '../includes/DbOperation.php';
 
 //function validating all the paramters are available
 //we will pass the required parameters to this function 
 function isTheseParametersAvailable($params){
 //assuming all parameters are available 
 $available = true; 
 $missingparams = ""; 
 
 foreach($params as $param){
 if(!isset($_POST[$param]) || strlen($_POST[$param])<=0){
 $available = false; 
 $missingparams = $missingparams . ", " . $param; 
 }
 }
 
 //if parameters are missing 
 if(!$available){
 $response = array(); 
 $response['error'] = true; 
 $response['message'] = 'Parameters ' . substr($missingparams, 1, strlen($missingparams)) . ' missing';
 
 //displaying error
 echo json_encode($response);
 
 //stopping further execution
 die();
 }
 }
 
 //an array to display response
 $response = array();
 
 //if it is an api call 
 //that means a get parameter named api call is set in the URL 
 //and with this parameter we are concluding that it is an api call
 if(isset($_GET['apicall'])){
 
 switch($_GET['apicall']){
 
 //user sign up
 case 'user_signup':
 //first check the parameters required for this request are available or not 
 isTheseParametersAvailable(array('User_NIC','User_Name','User_MobileNo','User_Pswd','UserGroup_Name','UserGroup_ID'));
 
 //creating a new dboperation object
 $db = new DbOperation();
 
 //creating a new record in the database
 $result = $db->user_signup(
 $_POST['User_NIC'],
 $_POST['User_Name'],
 $_POST['User_MobileNo'],
 $_POST['User_Pswd'],
 $_POST['UserGroup_Name'],
 $_POST['UserGroup_ID']
 );
 
 
 //if the record is created adding success to response
 if($result){
 //record is created means there is no error
 $response['error'] = false; 
 
 //in message we have a success message
 $response['message'] = 'User added successfully';
 
 //and we are getting all the users from the database in the response
 $response['users'] = $db->getUsers();
 }else{
 
 //if record is not added that means there is an error 
 $response['error'] = true; 
 
 //and we have the error message
 $response['message'] = 'Some error occurred please try again';
 }
 
 break; 
 
 //get all the users
 case 'get_users':
 $db = new DbOperation();
 $response['error'] = false; 
 $response['message'] = 'Request successfully completed';
 $response['users'] = $db->getUsers();
 break; 

 //add new employee
 case 'add_emp':
 //first check the parameters required for this request are available or not 
 isTheseParametersAvailable(array('Emp_NIC','UserGroup_ID','Emp_Name','Emp_Mobile_Num','Sent_User','UserGroup_Name'));
 
 //creating a new dboperation object
 $db = new DbOperation();
 
 //creating a new record in the database
 $result = $db->AddNEmp(
 $_POST['Emp_NIC'],
 $_POST['UserGroup_ID'],
 $_POST['Emp_Name'],
 $_POST['Emp_Mobile_Num'],
 $_POST['Sent_User'],
 $_POST['UserGroup_Name']
 );
 
 
 //if the record is created adding success to response
 if($result){
 //record is created means there is no error
 $response['error'] = false; 
 
 //in message we have a success message
 $response['message'] = 'Employee added';
 
 //and we are getting all the users from the database in the response
 $response['emps'] = $db->getEmps();
 }else{
 
 //if record is not added that means there is an error 
 $response['error'] = true; 
 
 //and we have the error message
 $response['message'] = 'Some error occurred please try again';
 }
 
 break; 
 
 //get all the employees
 case 'get_emp':
 $db = new DbOperation();
 $response['error'] = false; 
 $response['message'] = 'Request successfully completed';
 $response['emps'] = $db->getEmps();
 break; 
 
 
 //enter notice
  case 'user_enternotice':
 //first check the parameters required for this request are available or not 
 isTheseParametersAvailable(array('UserGroup_ID','Notice_Priority','Notice_Description','Notice_ToWhom','Notice_From','Notice_From_U_Type','Notice_SendDate','Notice_SendTime','Lang_Type'));
 
 //creating a new dboperation object
 $db = new DbOperation();
 
 //creating a new record in the database
 $result = $db->user_enternotice(
 $_POST['UserGroup_ID'],
 $_POST['Notice_Priority'],
 $_POST['Notice_Description'],
 $_POST['Notice_ToWhom'],
 $_POST['Notice_From'],
 $_POST['Notice_From_U_Type'],
 $_POST['Notice_SendDate'],
 $_POST['Notice_SendTime'],
 $_POST['Lang_Type']
 );
 
 
 //if the record is created adding success to response
 if($result){
 //record is created means there is no error
 $response['error'] = false; 
 
 //in message we have a success message
 $response['message'] = 'Notice addedd successfully';
 
 //and we are getting all the notices from the database in the response
 $response['notices'] = $db->getNotices();
 }else{
 
 //if record is not added that means there is an error 
 $response['error'] = true; 
 
 //and we have the error message
 $response['message'] = 'Some error occurred please try again';
 }
 
 break; 

 case 'get_notices':
 $db = new DbOperation();
 $response['error'] = false; 
 $response['message'] = 'Request successfully completed';
 $response['notices'] = $db->getNotices();
 break;
 


 //create user group
  case 'user_groupcreate':
 //first check the parameters required for this request are available or not 
 isTheseParametersAvailable(array('UserGroup_Name'));
 
 //creating a new dboperation object
 $db = new DbOperation();
 
 //creating a new record in the database
 $result = $db->user_groupcreate(
 $_POST['UserGroup_Name'] //,
 );
 
 
 //if the record is created adding success to response
 if($result){
 //record is created means there is no error
 $response['error'] = false; 
 
 //in message we have a success message
 $response['message'] = 'Group addedd successfully';
 
 //and we are getting all the groups from the database in the response
 $response['groups'] = $db->getGroups();
 }else{
 
 //if record is not added that means there is an error 
 $response['error'] = true; 
 
 //and we have the error message
 $response['message'] = 'Some error occurred please try again';
 }
 
 break; 

 case 'get_groups':
 $db = new DbOperation();
 $response['error'] = false; 
 $response['message'] = 'Request successfully completed';
 $response['groups'] = $db->getGroups();
 break;


  //assign emps to user group
  case 'emp_assign':
 //first check the parameters required for this request are available or not 
 isTheseParametersAvailable(array('UserGroup_ID','UserGroup_Name','Sent_User','Emp_NIC'));
 
 //creating a new dboperation object
 $db = new DbOperation();
 
 //creating a new record in the database
 $result = $db->emp_assign(
 $_POST['UserGroup_ID'],
 $_POST['UserGroup_Name'],
 $_POST['Sent_User'],
 $_POST['Emp_NIC']
 );
 
 
 //if the record is created adding success to response
 if($result){
 //record is created means there is no error
 $response['error'] = false; 
 
 //in message we have a success message
 $response['message'] = 'Employee Assigned successfully';
 
 //and we are getting all the emps from the database in the response
 $response['emps'] = $db->assignEmp();
 }else{
 
 //if record is not added that means there is an error 
 $response['error'] = true; 
 
 //and we have the error message
 $response['message'] = 'Some error occurred please try again';
 }
 
 break; 

 case 'get_assign_emp':
 $db = new DbOperation();
 $response['error'] = false; 
 $response['message'] = 'Request successfully completed';
 $response['emps'] = $db->assignEmp();
 break;


//update emp mobile num
 case 'emp_update':
 isTheseParametersAvailable(array('Emp_Mobile_Num','UserGroup_Name','Emp_NIC'));
 $db = new DbOperation();
 $result = $db->emp_update(
 $_POST['Emp_Mobile_Num'],
 $_POST['UserGroup_Name'],
 $_POST['Emp_NIC']
 );
 
 if($result){
 $response['error'] = false; 
 $response['message'] = 'Employee updated successfully';
 $response['emps'] = $db->assignEmp();
 }else{
 $response['error'] = true; 
 $response['message'] = 'Some error occurred please try again';
 }
 break; 
 
 //the delete operation
 case 'emp_remove':
 
 //for the delete operation we are getting a GET parameter from the url having the Emp_NIC of the record to be deleted
 if(isset($_GET['Emp_NIC'])){
 $db = new DbOperation();
 if($db->deleteEmp($_GET['Emp_NIC'])){
 $response['error'] = false; 
 $response['message'] = 'Employee deleted successfully';
 $response['emps'] = $db->assignEmp();
 }else{
 $response['error'] = true; 
 $response['message'] = 'Some error occurred please try again';
 }
 }else{
 $response['error'] = true; 
 $response['message'] = 'Nothing to delete, provide an Emp_NIC please';
 }
 break; 
 }
 
 }else{
 //if it is not api call 
 //pushing appropriate values to response array 
 $response['error'] = true; 
 $response['message'] = 'Invalid API Call';
 }
 
 //displaying the response in json structure 
 echo json_encode($response);
 ?>